Portfolio update: German CV (Deutsch only)
==========================================
Target repository: VasanthkumarSelvakumar/VasanthkumarSelvakumar.github.io

1. Upload assets/cv/Vasanthkumar_Selvakumar_Lebenslauf_DE.pdf to the same path in your repository.
2. In the *German-language section only* of the portfolio, make the existing CV download button or link point to:
   /assets/cv/Vasanthkumar_Selvakumar_Lebenslauf_DE.pdf
3. German button label: "Lebenslauf herunterladen (PDF)".
4. Keep the English CV and the English side unchanged.

Example HTML for a German-only section:
<a href="/assets/cv/Vasanthkumar_Selvakumar_Lebenslauf_DE.pdf" target="_blank" rel="noopener noreferrer" download="Vasanthkumar_Selvakumar_Lebenslauf_DE.pdf">Lebenslauf herunterladen (PDF)</a>

The PDF is a PUBLIC-SAFE variant of the supplied CV: the street address and mobile phone number were removed and replaced by Rostock, Deutschland and the existing email address. All other CV content was left unchanged. The source PDF itself is not included in this package.

Note: This package prepares an upload; it has NOT been published to GitHub yet. Existing portfolio file structure has not been inspected, so choose the right DE-only link location in the site code.
